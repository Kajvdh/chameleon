<?php
/* Smarty version 3.1.29, created on 2016-02-06 22:30:05
  from "/var/www/html/templates/chat_end.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56b665dd113d89_68608940',
  'file_dependency' => 
  array (
    'c6287cd045727db5a8c189931588c6bd66d07dde' => 
    array (
      0 => '/var/www/html/templates/chat_end.tpl',
      1 => 1454792895,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56b665dd113d89_68608940 ($_smarty_tpl) {
?>
</body>
</html>
<?php }
}
