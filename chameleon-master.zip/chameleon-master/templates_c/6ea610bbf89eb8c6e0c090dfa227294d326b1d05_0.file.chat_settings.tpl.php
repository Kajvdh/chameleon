<?php
/* Smarty version 3.1.29, created on 2016-02-07 12:09:13
  from "/var/www/html/templates/chat_settings.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56b725d9203f79_98389934',
  'file_dependency' => 
  array (
    '6ea610bbf89eb8c6e0c090dfa227294d326b1d05' => 
    array (
      0 => '/var/www/html/templates/chat_settings.tpl',
      1 => 1454792895,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56b725d9203f79_98389934 ($_smarty_tpl) {
?>
<div class="datacontainer" id="data">  
    Je kan je instellingen beheren in <a href='http://irc1.chattersweb.nl:8081' target='_blank'>het instellingenpaneel</a>.
</div><?php }
}
