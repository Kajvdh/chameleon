# Opensourced at 2020/05/29

Since I'm not working on this project anymore for a while now, I decided to opensource it because a reasonable amount of people are still interested in it. I hope that I can help some of you this way, please note that I am no longer maintaining this project. Also apologize me for the outdated tech stack that's been used, I did not know any better at the moment of coding ;-)

Yes, I also know that there are some passwords hidden in the code ;) They don't work anymore so what's the point in replacing them by placeholders anyway ¯\\_(ツ)_/¯
